
from api_egres import DllReadMorphBin


class StarfieldMorphFile:
    def __init__(self):
        pass

    def LoadMorph(self, morph_path):
        DllReadMorphBin(morph_path.encode('utf-8'))


if __name__ == "__main__":
    temp_path = "D:/Docs/GameModding/sf/extracted_archive/meshes/morphs/human/_1stperson/male/hands/morph.dat"
    morph = StarfieldMorphFile()
    morph.LoadMorph(temp_path)
    